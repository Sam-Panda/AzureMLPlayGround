def print_statement(message):
    print(message)